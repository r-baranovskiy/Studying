//
//  X4X0R_NewsApp.swift
//  X4X0R News
//
//  Created by Кащенко on 15.01.23.
//

import SwiftUI

@main
struct X4X0R_NewsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
